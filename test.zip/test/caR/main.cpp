#include <QApplication>
#include <QSystemTrayIcon>
#include <QMenu>
#include <QDebug>
#include "mainwindow.h"
#include "globalhotkeymanager.h"

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);

    // 創建主窗口
    MainWindow mainWindow;
    mainWindow.setWindowFlags(Qt::WindowStaysOnTopHint);
    mainWindow.show(); // 主窗口初始隱藏

    // 創建系統托盤圖示
    QSystemTrayIcon trayIcon;
    trayIcon.setIcon(QIcon(":/image/wait.png")); // 替換為你的圖示資源路徑
    trayIcon.setToolTip("Qt 程式 - 後臺運行中");

    // 創建托盤菜單
    QMenu trayMenu;
    QAction showAction("顯示主窗口", &trayMenu);
    QAction quitAction("退出程序", &trayMenu);
    trayMenu.addAction(&showAction);
    trayMenu.addAction(&quitAction);

    // 設置托盤菜單
    trayIcon.setContextMenu(&trayMenu);
    trayIcon.show();

    // 顯示主窗口
    QObject::connect(&showAction, &QAction::triggered, [&mainWindow]() {
        mainWindow.show();
        mainWindow.setFocus();
    });

    // 退出程序
    QObject::connect(&quitAction, &QAction::triggered, &app, &QApplication::quit);

    // 初始化全域熱鍵管理器
    GlobalHotkeyManager hotkeyManager;

    // 註冊熱鍵
    hotkeyManager.registerHotkey("W", [&]() { mainWindow.handleKeyPress('W'); });
    hotkeyManager.registerHotkey("A", [&]() { mainWindow.handleKeyPress('A'); });
    hotkeyManager.registerHotkey("S", [&]() { mainWindow.handleKeyPress('S'); });
    hotkeyManager.registerHotkey("D", [&]() { mainWindow.handleKeyPress('D'); });

    return app.exec();
}
