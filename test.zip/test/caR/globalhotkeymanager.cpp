#include "globalhotkeymanager.h"
#include <QDebug>

GlobalHotkeyManager *GlobalHotkeyManager::m_instance = nullptr;
HHOOK GlobalHotkeyManager::m_keyboardHook = nullptr; // 初始化靜態成員

GlobalHotkeyManager::GlobalHotkeyManager(QObject *parent)
    : QObject(parent)
{
    m_instance = this;
}

GlobalHotkeyManager::~GlobalHotkeyManager()
{
    unregisterAllHotkeys();
    stopKeyboardHook(); // 停止鍵盤鉤子
}

void GlobalHotkeyManager::registerHotkey(const QString &key, std::function<void()> callback)
{
    int id = key[0].toUpper().unicode();
    if (RegisterHotKey(nullptr, id, 0, id)) {
        m_hotkeyCallbacks[id] = callback;
        qDebug() << "Registered hotkey:" << key;
    } else {
        qDebug() << "Failed to register hotkey:" << key;
    }
}

void GlobalHotkeyManager::unregisterAllHotkeys()
{
    for (const auto &pair : m_hotkeyCallbacks) {
        UnregisterHotKey(nullptr, pair.first);
    }
    m_hotkeyCallbacks.clear();
}

LRESULT CALLBACK GlobalHotkeyManager::hotkeyProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    if (uMsg == WM_HOTKEY) {
        int id = static_cast<int>(wParam);
        if (m_instance && m_instance->m_hotkeyCallbacks.find(id) != m_instance->m_hotkeyCallbacks.end()) {
            m_instance->m_hotkeyCallbacks[id]();
        }
    }
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

void startHotkeyMessageLoop()
{
    MSG msg;
    while (GetMessage(&msg, nullptr, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
}

void GlobalHotkeyManager::startKeyboardHook()
{
    if (!m_keyboardHook) {
        m_keyboardHook = SetWindowsHookEx(WH_KEYBOARD_LL, keyboardHookProc, nullptr, 0);
        if (!m_keyboardHook) {
            qDebug() << "Failed to set keyboard hook.";
        } else {
            qDebug() << "Keyboard hook started.";
        }
    }
}

void GlobalHotkeyManager::stopKeyboardHook()
{
    if (m_keyboardHook) {
        UnhookWindowsHookEx(m_keyboardHook);
        m_keyboardHook = nullptr;
        qDebug() << "Keyboard hook stopped.";
    }
}

LRESULT CALLBACK GlobalHotkeyManager::keyboardHookProc(int nCode, WPARAM wParam, LPARAM lParam)
{
    if (nCode >= 0 && wParam == WM_KEYDOWN) {
        KBDLLHOOKSTRUCT *pKeyBoard = (KBDLLHOOKSTRUCT *)lParam;
        int vkCode = pKeyBoard->vkCode;

        // 檢查是否為已註冊的熱鍵
        if (m_instance->m_hotkeyCallbacks.find(vkCode) != m_instance->m_hotkeyCallbacks.end()) {
            m_instance->m_hotkeyCallbacks[vkCode](); // 執行熱鍵回呼
            return 1; // 攔截事件，防止傳遞
        }
    }

    // 未處理的按鍵事件繼續傳遞
    return CallNextHookEx(m_keyboardHook, nCode, wParam, lParam);
}
