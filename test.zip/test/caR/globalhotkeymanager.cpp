#include "globalhotkeymanager.h"
#include <QDebug>

GlobalHotkeyManager *GlobalHotkeyManager::m_instance = nullptr;

GlobalHotkeyManager::GlobalHotkeyManager(QObject *parent)
    : QObject(parent)
{
    m_instance = this;
}

GlobalHotkeyManager::~GlobalHotkeyManager()
{
    unregisterAllHotkeys();
}

void GlobalHotkeyManager::registerHotkey(const QString &key, std::function<void()> callback)
{
    int id = key[0].toUpper().unicode(); // 將字母轉換為對應的虛擬鍵碼
    if (RegisterHotKey(nullptr, id, 0, id)) {
        m_hotkeyCallbacks[id] = callback;
        qDebug() << "Registered hotkey:" << key;
    } else {
        qDebug() << "Failed to register hotkey:" << key;
    }
}

void GlobalHotkeyManager::unregisterAllHotkeys()
{
    for (const auto &pair : m_hotkeyCallbacks) {
        UnregisterHotKey(nullptr, pair.first);
    }
    m_hotkeyCallbacks.clear();
}

LRESULT CALLBACK GlobalHotkeyManager::hotkeyProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    if (uMsg == WM_HOTKEY) {
        int id = static_cast<int>(wParam);
        if (m_instance->m_hotkeyCallbacks.find(id) != m_instance->m_hotkeyCallbacks.end()) {
            m_instance->m_hotkeyCallbacks[id]();
        }
    }
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}
