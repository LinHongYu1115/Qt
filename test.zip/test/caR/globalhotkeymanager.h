#ifndef GLOBALHOTKEYMANAGER_H
#define GLOBALHOTKEYMANAGER_H

#include <QObject>
#include <functional>
#include <windows.h>
#include <unordered_map>

class GlobalHotkeyManager : public QObject
{
    Q_OBJECT

public:
    GlobalHotkeyManager(QObject *parent = nullptr);
    ~GlobalHotkeyManager();

    void registerHotkey(const QString &key, std::function<void()> callback);
    void unregisterAllHotkeys();
    void startKeyboardHook();
    void stopKeyboardHook();

private:
    static LRESULT CALLBACK hotkeyProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
    static LRESULT CALLBACK keyboardHookProc(int nCode, WPARAM wParam, LPARAM lParam); // 添加這行聲明

    std::unordered_map<int, std::function<void()>> m_hotkeyCallbacks;
    static GlobalHotkeyManager *m_instance;
    static HHOOK m_keyboardHook;
};

void startHotkeyMessageLoop();

#endif // GLOBALHOTKEYMANAGER_H
