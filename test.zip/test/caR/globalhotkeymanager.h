#ifndef GLOBALHOTKEYMANAGER_H
#define GLOBALHOTKEYMANAGER_H

#include <QObject>
#include <functional>
#include <windows.h>
#include <unordered_map>

class GlobalHotkeyManager : public QObject
{
    Q_OBJECT

public:
    GlobalHotkeyManager(QObject *parent = nullptr);
    ~GlobalHotkeyManager();

    void registerHotkey(const QString &key, std::function<void()> callback);
    void unregisterAllHotkeys();

private:
    static LRESULT CALLBACK hotkeyProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

    std::unordered_map<int, std::function<void()>> m_hotkeyCallbacks;
    static GlobalHotkeyManager *m_instance;
};

#endif // GLOBALHOTKEYMANAGER_H
