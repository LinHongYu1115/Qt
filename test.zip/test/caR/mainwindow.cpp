#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QKeyEvent>
#include <QPixmap>
#include <QDebug>
#include <QFile>
#include <QMediaPlayer>
#include <QAudioOutput>
#include <QUrl>
#include <QTimer>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // 設置初始圖片為 wait.png
    QPixmap pixmap(":/image/wait.png");
    ui->imageLabel->setPixmap(pixmap.scaled(ui->imageLabel->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::keyPressEvent(QKeyEvent *event)
{
    qDebug() << "Key pressed:" << event->key();
    QString imagePath = ":/image/wait.png"; // 默認顯示 wait.png
    if (event->key() == Qt::Key_W) {
        imagePath = ":/image/catW.png";
    } else if (event->key() == Qt::Key_A) {
        imagePath = ":/image/catA.png";
    } else if (event->key() == Qt::Key_S) {
        imagePath = ":/image/catS.png";
    } else if (event->key() == Qt::Key_D) {
        imagePath = ":/image/catD.png";
    } else if (event->key() == Qt::Key_P) {
        playSound("qrc:/image/pipefalling-sound.mp3");
        imagePath = ":/image/metalpipe.png";
    } else if (event->key() == Qt::Key_C) {
        playSound("qrc:/image/sounds_cowbell.mp3");
        imagePath = ":/image/cowbell.png";
    } else if (event->key() == Qt::Key_R) {
        playSound("qrc:/image/sounds_cymbal.mp3");
        imagePath = ":/image/cymbal.png";
    }

    QPixmap pixmap(imagePath);
    if (pixmap.isNull()) {
        qDebug() << "Failed to load image.";
    } else {
        ui->imageLabel->setPixmap(pixmap.scaled(ui->imageLabel->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation));
        qDebug() << "Image displayed.";
    }

    // 設置定時器在1秒後恢復原始圖片
    QTimer::singleShot(100, this, [this]() {
        QPixmap pixmap(":/image/wait.png");
        ui->imageLabel->setPixmap(pixmap.scaled(ui->imageLabel->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation));
        qDebug() << "Reverted to original image.";
    });
}

void MainWindow::playSound(const QString &url)
{
    QMediaPlayer *player = new QMediaPlayer(this);
    QAudioOutput *audioOutput = new QAudioOutput(this);
    player->setAudioOutput(audioOutput);
    player->setSource(QUrl(url));
    audioOutput->setVolume(0.5);
    player->play();
}
