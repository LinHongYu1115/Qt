#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QKeyEvent>
#include <QPixmap>
#include <QDebug>
#include <QFile>
#include "globalhotkeymanager.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , player(new QMediaPlayer(this))
    , audioOutput(new QAudioOutput(this))
{
    ui->setupUi(this);
    player->setAudioOutput(audioOutput);

    QPixmap pixmap(":/image/wait.png");
    ui->imageLabel->setPixmap(pixmap.scaled(ui->imageLabel->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation));

    auto hotkeyManager = new GlobalHotkeyManager(this); // 應該在這裡使用 `this`
    hotkeyManager->startKeyboardHook();

    // 註冊熱鍵回調
    hotkeyManager->registerHotkey("W", [this]() { handleKeyPress('W'); });
    hotkeyManager->registerHotkey("A", [this]() { handleKeyPress('A'); });
    hotkeyManager->registerHotkey("S", [this]() { handleKeyPress('S'); });
    hotkeyManager->registerHotkey("D", [this]() { handleKeyPress('D'); });

}


MainWindow::~MainWindow()
{
    delete ui;
}





void MainWindow::keyPressEvent(QKeyEvent *event)
{
    qDebug() << "Key pressed:" << event->key();
    QString imagePath = ":/image/wait.png";

    if (event->key() == Qt::Key_W) {
        imagePath = ":/image/catW.png";
    } else if (event->key() == Qt::Key_A) {
        imagePath = ":/image/catA.png";
    } else if (event->key() == Qt::Key_S) {
        imagePath = ":/image/catS.png";
    } else if (event->key() == Qt::Key_D) {
        imagePath = ":/image/catD.png";
    } else if (event->key() == Qt::Key_P) {
        playSound("qrc:/image/pipefalling-sound.mp3");
        imagePath = ":/image/metalpipe.png";
    } else if (event->key() == Qt::Key_C) {
        playSound("qrc:/image/sounds_cowbell.mp3");
        imagePath = ":/image/cowbell.png";
    } else if (event->key() == Qt::Key_R) {
        playSound("qrc:/image/sounds_cymbal.mp3");
        imagePath = ":/image/cymbal.png";
    }

    QPixmap pixmap(imagePath);
    if (pixmap.isNull()) {
        qDebug() << "Failed to load image.";
    } else {
        ui->imageLabel->setPixmap(pixmap.scaled(ui->imageLabel->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation));
        qDebug() << "Image displayed.";
    }

    QTimer::singleShot(1000, this, [this]() {
        QPixmap pixmap(":/image/wait.png");
        ui->imageLabel->setPixmap(pixmap.scaled(ui->imageLabel->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation));
        qDebug() << "Reverted to original image.";
    });
}

void MainWindow::handleKeyPress(char key)
{
    QString imagePath = ":/image/wait.png"; // 默認顯示 wait.png
    if (key == 'W') {
        imagePath = ":/image/catW.png";
    } else if (key == 'A') {
        imagePath = ":/image/catA.png";
    } else if (key == 'S') {
        imagePath = ":/image/catS.png";
    } else if (key == 'D') {
        imagePath = ":/image/catD.png";
    } else if (key == 'P') {
        playSound("qrc:/image/pipefalling-sound.mp3");
        imagePath = ":/image/metalpipe.png";
    } else if (key == 'C') {
        playSound("qrc:/image/sounds_cowbell.mp3");
        imagePath = ":/image/cowbell.png";
    } else if (key == 'R') {
        playSound("qrc:/image/sounds_cymbal.mp3");
        imagePath = ":/image/cymbal.png";
    }

    QPixmap pixmap(imagePath);
    if (pixmap.isNull()) {
        qDebug() << "Failed to load image.";
    } else {
        ui->imageLabel->setPixmap(pixmap.scaled(ui->imageLabel->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation));
        qDebug() << "Image displayed.";
    }

    // 設置定時器在1秒後恢復原始圖片
    QTimer::singleShot(1000, this, [this]() {
        QPixmap pixmap(":/image/wait.png");
        ui->imageLabel->setPixmap(pixmap.scaled(ui->imageLabel->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation));
        qDebug() << "Reverted to original image.";
    });
}

void MainWindow::playSound(const QString &url)
{
    player->setSource(QUrl(url));
    player->play();
}
